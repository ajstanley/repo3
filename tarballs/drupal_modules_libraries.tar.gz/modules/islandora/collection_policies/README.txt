This folder holds sample collection policy xml files.

These are not used by the module directly from this location but should
be added as datatreams to objects with a content model property of Collection or
Community.  The datastream id should be COLLECTION_POLICY.

PERSONAL-COLLECTION-POLCIY is referenced from code do not remove