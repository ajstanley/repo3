This directory holds content model xml files.  These files should be added
as datastreams to fedora objects.  The pid and datastream id are determined
by the collection policy stream of a collection object.