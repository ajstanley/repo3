The islandora_solr_search module allows users of the Islandora fedora repository
to search their Fedora Repository with a properly configured Solr instance.

This code used to display search results can be modified through an external customization
module.  Islandora_solr_config has been included as a template to show how this is done.

Translations can be enabled by installing the i18n Internationalization module, 
and updating the alias fields on the admin page in each required language.
