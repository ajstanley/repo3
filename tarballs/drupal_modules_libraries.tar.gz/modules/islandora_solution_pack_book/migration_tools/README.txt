This utility module will add the fedora relationships required by the current version of
the Islandora Book Solution Pack.  The module is intended for single use only.
If activated from the Navigation menu by clicking 'Add new Islandora RDF relationships to existing books'
EVERY BOOK IN YOUR FEDORA WILL BE UPDATED, whether its associated with your Drupla install or not.

If you are on a multisite it is safer to update on a collection by collection basis.
Select  'Manage This Collection' from within the collection you wish to update then select
'Add new Islandora relationships to book objects'
to update all the books within that particular collection.
