/* $Id: README.txt,v 1.1.2.1 2011/01/27 02:25:40 sun Exp $ */

-- SUMMARY --

Libraries API provides external library handling for Drupal modules.

For a full description visit the project page:
  http://drupal.org/project/libraries
Bug reports, feature suggestions and latest developments:
  http://drupal.org/project/issues/libraries


-- REQUIREMENTS --

* None.


-- INSTALLATION --

* Install as usual, see http://drupal.org/node/70151 for further information.


-- CONTACT --

Current maintainers:
* Daniel F. Kudwien (sun) - http://drupal.org/user/54136
* Tobias Stöckler (tstoeckler) - http://drupal.org/user/107158


This project has been sponsored by:
* UNLEASHED MIND
  Specialized in consulting and planning of Drupal powered sites, UNLEASHED
  MIND offers installation, development, theming, customization, and hosting
  to get you started. Visit http://www.unleashedmind.com for more information.

