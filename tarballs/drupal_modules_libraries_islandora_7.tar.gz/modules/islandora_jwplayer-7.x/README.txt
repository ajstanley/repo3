CONTENTS OF THIS FILE
---------------------

 * summary
 * installation
 * updates
 * licensing

SUMMARY
-------

A islandora viewer module using jwplayer.

INSTALLATION
------------

Install the jwplayer from http://www.longtailvideo.com/jw-player/download/
to your sites/libraries folder.  This viewer has been tested with jwplayer6.

www.longtailvideo.com/download/jwplayer-free-6-1-2972.zip

UPDATES
-------

This module has been updated to use jwplayer6.  If you are updating this module
for the first time since 22/01/2013 with an install predating that date your
library will need to be updated.

LICENSING
---------

This module uses jwplayer, jwplayer is free for non comercial use.
